#!/usr/bin/env python3
import os
import re
import sys
import json
import time
import threading
import subprocess
import urllib.request
from pathlib import Path
__version__ = "1.2.2.0"
__build__   = "stable"
B    = "\033[96m"  
C    = "\033[0m"  
G    = "\033[92m" 
R    = "\033[91m"  
Y    = "\033[93m"  
W    = "\033[97m"   
DIM  = "\033[2m"  
BOLD = "\033[1m" 
APP_DIR      = Path(__file__).resolve().parent
SCRAPE_DIR   = APP_DIR / "scrape"
DOWNLOAD_DIR = APP_DIR / "download"
PLATFORMS = {
    "1": ("Pinterest",  "Pinterest.js"),
    "2": ("SoundCloud", "SoundCloud.js"),
    "3": ("TikTok",     "TikTok.js"),
    "4": ("YouTube",    "YouTube.js"),
}
ALLOWED_EXT = {".mp3", ".mp4", ".jpg", ".jpeg", ".png", ".gif", ".webp"}
FORMAT_INTERMEDIATE = re.compile(
    r"\.f\d+\.(mp4|webm|m4a|opus|aac|ogg|3gp|mp3)$", re.IGNORECASE
)
SESSION = {"downloads": 0, "failed": 0, "cleaned": 0, "bytes": 0}
SPINNER_FRAMES = ["⠋", "⠙", "⠹", "⠸", "⠼", "⠴", "⠦", "⠧", "⠇", "⠏"]
DOTS_FRAMES = ["   ", ".  ", ".. ", "..."]
def clear():
    os.system("cls" if os.name == "nt" else "clear")
def banner():
    clear()
    print(f"""{B}
   _____                  ______                                  __
  / ___/____ __   _____  / ____/________  ____ ___    ____  ___  / /_
  \\__ \\/ __ `/ | / / _ \\/ /_  / ___/ __ \\/ __ `__ \\  / __ \\/ _ \\/ __/
 ___/ / /_/ /| |/ /  __/ __/ / /  / /_/ / / / / / / / / / /  __/ /_
/____/\\__,_/ |___/\\___/_/   /_/   \\____/_/ /_/ /_(_)_/ /_/\\___/\\__/
{C}""")
    print(f"{DIM}                    v{__version__}  -  {__build__}{C}\n")
def prompt(msg: str) -> str:
    try:
        return input(f"{B}{msg}{C} ").strip()
    except (EOFError, KeyboardInterrupt):
        print()
        return "0"
def pause(msg="Press Enter to continue..."):
    try:
        input(f"{DIM}  [!] {msg}{C}")
    except (EOFError, KeyboardInterrupt):
        print()
def step(n, total, msg):
    print(f"  {B}[{n}/{total}]{C}  {msg}")
def fmt_size(num_bytes):
    kb = num_bytes / 1024
    mb = kb / 1024
    return f"{mb:.2f} MB" if mb >= 1 else f"{kb:.1f} KB"
def detail(label, value, indent=6):
    pad = " " * indent
    print(f"{pad}{B}{label:<10}{C} {value}")
def typewriter(text, delay=0.015, indent=2, color=None):
    color = color or B
    sys.stdout.write(" " * indent)
    sys.stdout.flush()
    for ch in text:
        sys.stdout.write(f"{color}{ch}{C}")
        sys.stdout.flush()
        time.sleep(delay)
    print()
def dots_animation(text, delay=0.25, cycles=3, indent=2, color=None):
    color = color or B
    for _ in range(cycles):
        for frame in DOTS_FRAMES:
            sys.stdout.write(f"\r{' ' * indent}{color}{text}{C} {Y}{frame}{C}")
            sys.stdout.flush()
            time.sleep(delay)
    sys.stdout.write(f"\r{' ' * indent}{color}{text}{C}    \n")
    sys.stdout.flush()
class Spinner:
    def __init__(self, message="Working", indent=2, frames=None):
        self.message = message
        self.indent = indent
        self.frames = frames or SPINNER_FRAMES
        self.running = False
        self.thread = None
        self._line = ""
        self.start_time = 0
    def _spin(self):
        i = 0
        while self.running:
            elapsed = time.time() - self.start_time
            frame = self.frames[i % len(self.frames)]
            self._line = (
                f"{' ' * self.indent}"
                f"{Y}{frame}{C}  {self.message}  "
                f"{DIM}({elapsed:.1f}s){C}"
            )
            sys.stdout.write("\r" + self._line + "    ")
            sys.stdout.flush()
            time.sleep(0.08)
            i += 1
    def start(self):
        self.running = True
        self.start_time = time.time()
        self.thread = threading.Thread(target=self._spin, daemon=True)
        self.thread.start()
    def update(self, message):
        self.message = message
    def stop(self, final=None):
        self.running = False
        if self.thread:
            self.thread.join()
        elapsed = time.time() - self.start_time
        sys.stdout.write("\r" + " " * (len(self._line) + 20) + "\r")
        sys.stdout.flush()
        if final is not None:
            pad = " " * self.indent
            print(f"{pad}{final}  {DIM}({elapsed:.1f}s){C}")
def progress_bar(duration=0.8, width=24, indent=6, label="Saving"):
    frames = width
    for i in range(frames + 1):
        pct = int((i / frames) * 100)
        filled = "█" * i + "░" * (frames - i)
        sys.stdout.write(
            f"\r{' ' * indent}{B}{label:<8}{C} {G}{filled}{C} {W}{pct:>3}%{C}"
        )
        sys.stdout.flush()
        time.sleep(duration / frames)
    print()
def is_junk(name: str) -> bool:
    lower = name.lower()
    for ext in (".ytdl", ".part", ".temp", ".tmp", ".frag"):
        if lower.endswith(ext):
            return True
    if FORMAT_INTERMEDIATE.search(lower):
        return True
    ext = Path(name).suffix.lower()
    return ext not in ALLOWED_EXT
def cleanup_downloads(verbose=True):
    removed = []
    if not DOWNLOAD_DIR.exists():
        return removed
    for f in DOWNLOAD_DIR.iterdir():
        if not f.is_file():
            continue
        if is_junk(f.name):
            try:
                size = f.stat().st_size
                f.unlink()
                removed.append((f.name, size))
                SESSION["cleaned"] += 1
            except Exception:
                pass
    if verbose and removed:
        print(f"  {Y}[!]{C}  Cleaned {len(removed)} temp file(s)")
        for name, size in removed[:4]:
            print(f"       {R}×{C} {name} {DIM}({fmt_size(size)}){C}")
        if len(removed) > 4:
            print(f"       {DIM}...and {len(removed) - 4} more{C}")
        print()

    return removed
def run_scraper(platform: str, script: str, url: str, extra_args=None):
    script_path = SCRAPE_DIR / script
    if not script_path.exists():
        print(f"  {R}[×]{C}  Scraper not found: {script}")
        return None
    cmd = ["node", str(script_path), url]
    if extra_args:
        cmd.extend(extra_args)
    spinner = Spinner(f"Contacting {platform}")
    spinner.start()
    try:
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=180)
    except FileNotFoundError:
        spinner.stop(f"{R}[×]{C}  Node.js not found")
        return None
    except subprocess.TimeoutExpired:
        spinner.stop(f"{R}[×]{C}  Request timed out")
        return None
    stdout = (result.stdout or "").strip()
    if not stdout:
        err = (result.stderr or "").strip() or "unknown error"
        spinner.stop(f"{R}[×]{C}  Scraper failed: {err[:50]}")
        return None
    try:
        line = stdout.splitlines()[-1]
        data = json.loads(line)
    except Exception as e:
        spinner.stop(f"{R}[×]{C}  Invalid response: {e}")
        return None
    if not data.get("success"):
        err = data.get("error") or data.get("message") or "unknown error"
        spinner.stop(f"{R}[×]{C}  {err[:60]}")
        return data
    spinner.stop(f"{G}[✓]{C}  Data fetched")
    return data
def save_direct(url: str, name: str, kind: str):
    ext = {"video": "mp4", "audio": "mp3", "image": "jpg"}.get(kind, "bin")
    out = DOWNLOAD_DIR / f"{name}.{ext}"
    print(f"  {Y}[*]{C}  Direct download starting")
    spinner = Spinner(f"Downloading {out.name}", indent=6)
    spinner.start()
    try:
        req = urllib.request.Request(url, headers={
            "User-Agent": "Mozilla/5.0",
            "Referer": "https://musicaldown.net/"
        })
        with urllib.request.urlopen(req, timeout=60) as r, open(out, "wb") as f:
            f.write(r.read())
        size = out.stat().st_size
        SESSION["bytes"] += size
        spinner.stop(f"{G}[✓]{C}  Saved: download/{out.name}")
        progress_bar(0.6, indent=6, label="Saving")
        print(f"       {DIM}{fmt_size(size)}{C}")
        return True
    except Exception as e:
        spinner.stop(f"{R}[×]{C}  Download failed: {e}")
        return False
def pick_format(platform: str):
    if platform == "YouTube":
        print(f"       {B}[1]{C}  MP3   {DIM}audio only{C}")
        print(f"       {B}[2]{C}  MP4   {DIM}video{C}")
        choice = prompt("[?] Select format:")
        if choice == "1": return ["mp3"]
        if choice == "2": return ["mp4"]
        print(f"  {R}[×]{C}  Invalid format.")
        return None
    if platform == "TikTok":
        print(f"       {B}[1]{C}  MP4   {DIM}video{C}")
        print(f"       {B}[2]{C}  MP3   {DIM}audio only{C}")
        choice = prompt("[?] Select format:")
        if choice == "1": return ["mp4"]
        if choice == "2": return ["mp3"]
        print(f"  {R}[×]{C}  Invalid format.")
        return None
    return []
def show_result(data, platform):
    print()
    dots_animation("Finalizing", delay=0.2, cycles=2, indent=2, color=G)
    print()
    print(f"  {G}[✓]{C}  {BOLD}{W}Success{C}")
    print()
    detail("Platform", data.get("platform", platform))
    detail("Title",    data.get("title", "-"))
    detail("Author",   data.get("author", "-"))
    detail("Type",     data.get("type", "-"))
    if data.get("id"):       detail("ID",       data["id"])
    if data.get("filename"): detail("Filename", data["filename"])
    if data.get("size"):     detail("Size",     fmt_size(data["size"]))
    if data.get("filepath"): detail("Path",     data["filepath"])
    if data.get("method"):   detail("Method",   data["method"])
    if data.get("creator"):  detail("Creator",  data["creator"])
    print()
def handle_download(platform: str, script: str):
    while True:
        print()
        typewriter(f"{platform} Downloader", delay=0.012, indent=2, color=B)
        print()
        step(1, 3, f"Enter {platform} URL")
        url = prompt("    [+] URL:")
        if not url:
            print(f"  {R}[×]{C}  URL cannot be empty.")
            return
        extra_args = []
        if platform in ("YouTube", "TikTok"):
            step(2, 3, "Select output format")
            extra_args = pick_format(platform)
            if extra_args is None:
                return
        else:
            step(2, 3, "Using default format")

        step(3, 3, "Processing")
        print()
        data = run_scraper(platform, script, url, extra_args)
        if not data:
            print()
            pause()
            return
        if not data.get("success"):
            print()
            print(f"  {Y}[!]{C}  Partial result - metadata only")
            print()
            if data.get("title"):
                detail("Title",    data["title"])
            if data.get("download"):
                detail("Download", data["download"][:70] + "...")
            print()
            if data.get("download"):
                choice = prompt("    [?] Try Python fallback save? [y/n]:").lower()
                if choice == "y":
                    save_direct(
                        data["download"],
                        str(data.get("id", platform.lower())),
                        data.get("type", "video"),
                    )
            print()
            pause()
            return
        SESSION["downloads"] += 1
        if data.get("size"):
            SESSION["bytes"] += data["size"]
        show_result(data, platform)
        if data.get("download") and not data.get("filename"):
            print(f"  {B}URL:{C} {data['download'][:80]}...")
            choice = prompt("    [?] Save to download/ folder? [y/n]:").lower()
            if choice == "y":
                save_direct(
                    data["download"],
                    str(data.get("id", platform.lower())),
                    data.get("type", "image"),
                )
                print()
        cleanup_downloads(verbose=True)
        again = prompt(f"    [?] Download another {platform}? [y/n]:").lower()
        if again != "y":
            break
def menu():
    print(f"  {BOLD}{W}Available Platforms{C}\n")
    for k, (name, _) in PLATFORMS.items():
        print(f"    {B}[{k}]{C}  {name}")
    print(f"    {R}[0]{C}  Exit")
    print()
def show_stats():
    print()
    print(f"  {BOLD}{W}Session Summary{C}\n")
    print(f"    {G}[✓]{C}  Downloads  :  {W}{SESSION['downloads']}{C}")
    print(f"    {Y}[!]{C}  Cleaned    :  {W}{SESSION['cleaned']}{C}")
    if SESSION["bytes"]:
        print(f"    {B}[*]{C}  Total size :  {W}{fmt_size(SESSION['bytes'])}{C}")
    print(f"    {DIM}Output: {DOWNLOAD_DIR}{C}")
    print(f"    {DIM}Version: v{__version__} ({__build__}){C}")
    print()
def main():
    DOWNLOAD_DIR.mkdir(exist_ok=True)
    banner()
    dots_animation("Scanning download folder", delay=0.18, cycles=2, indent=2, color=B)
    cleanup_downloads(verbose=True)
    menu()
    while True:
        choice = prompt("[?] Select platform:").lower()
        if choice in ("0", "exit", "quit"):
            show_stats()
            print(f"  {G}[✓]{C}  Goodbye.")
            break
        if choice not in PLATFORMS:
            print(f"  {R}[×]{C}  Invalid option. Choose 1-4 or 0.\n")
            continue
        platform, script = PLATFORMS[choice]
        handle_download(platform, script)
        banner()
        menu()
if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print(f"\n  {Y}[!]{C}  Interrupted.")
        show_stats()
        sys.exit(0)