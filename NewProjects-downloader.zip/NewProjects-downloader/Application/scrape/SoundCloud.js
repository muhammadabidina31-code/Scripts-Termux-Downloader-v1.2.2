const { exec } = require('child_process');
const util = require('util');
const execPromise = util.promisify(exec);
const fs = require('fs');
const path = require('path');
const args = process.argv.slice(2);
const url = args[0];

const DOWNLOAD_DIR = path.join(__dirname, '..', 'download');
if (!fs.existsSync(DOWNLOAD_DIR)) {
    fs.mkdirSync(DOWNLOAD_DIR, { recursive: true });
}

if (!url) {
    console.log(JSON.stringify({
        success: false,
        error: 'Usage: node SoundCloud.js <track_url>'
    }));
    process.exit(1);
}

function getFilename(title) {
    if (!title) return 'soundcloud_track.mp3';
    return title
        .replace(/[^a-zA-Z0-9\s-]/g, '')
        .replace(/\s+/g, '_')
        .substring(0, 50) + '.mp3';
}

async function downloadTrack(url) {
    try {
        const { stdout: titleOutput } = await execPromise(
            `yt-dlp --get-title "${url}" 2>/dev/null`
        );
        const title = titleOutput.trim() || 'soundcloud_track';
        const filename = getFilename(title);
        const outPath = path.join(DOWNLOAD_DIR, filename);
        await execPromise(
            `yt-dlp -f bestaudio --extract-audio --audio-format mp3 --audio-quality 0 -o "${outPath}" "${url}" 2>/dev/null`
        );

        const stats = fs.statSync(outPath);

        return {
            success: true,
            id: path.basename(filename, '.mp3'),
            platform: 'SoundCloud',
            title: title,
            author: 'unknown',
            type: 'audio',
            filename: filename,
            filepath: `download/${filename}`,
            size: stats.size,
            download: `download/${filename}`,
            creator: 'Exproject'
        };

    } catch (error) {
        return {
            success: false,
            error: error.message,
            creator: 'Exproject'
        };
    }
}

async function main() {
    try {
        const result = await downloadTrack(url);
        console.log(JSON.stringify(result));
    } catch (error) {
        console.log(JSON.stringify({
            success: false,
            error: error.message,
            creator: 'Exproject'
        }));
        process.exit(1);
    }
}

main();