const axios = require('axios');
const fs = require('fs');
const path = require('path');
const { exec } = require('child_process');
const util = require('util');
const execPromise = util.promisify(exec);
const args = process.argv.slice(2);
const url = args[0];
const format = (args[1] || 'mp4').toLowerCase();
const DOWNLOAD_DIR = path.join(__dirname, '..', 'download');
if (!fs.existsSync(DOWNLOAD_DIR)) {
    fs.mkdirSync(DOWNLOAD_DIR, { recursive: true });
}

if (!url) {
    console.log(JSON.stringify({
        success: false,
        error: 'Usage: node YouTube.js <url> [mp3|mp4]'
    }));
    process.exit(1);
}

if (!['mp3', 'mp4'].includes(format)) {
    console.log(JSON.stringify({
        success: false,
        error: `Unsupported format: ${format}. Use mp3 or mp4.`
    }));
    process.exit(1);
}

function safeName(title) {
    return (title || 'youtube_media')
        .substring(0, 50)
        .replace(/[^a-zA-Z0-9\s-]/g, '')
        .replace(/\s+/g, '_') || 'youtube_media';
}

async function getVideoInfo(youtubeUrl) {
    try {
        const videoId = youtubeUrl.match(/(?:v=|\/)([0-9A-Za-z_-]{11})(?:[?&]|$)/)?.[1];
        if (!videoId) throw new Error('Invalid YouTube URL');

        const response = await axios.get(
            `https://www.youtube.com/oembed?url=https://www.youtube.com/watch?v=${videoId}&format=json`,
            {
                headers: { 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)' },
                timeout: 10000
            }
        );

        return {
            title: response.data.title || 'youtube_media',
            videoId: videoId,
            author: response.data.author_name || 'unknown',
            thumbnail: response.data.thumbnail_url || null
        };
    } catch (error) {
        const videoId = youtubeUrl.match(/(?:v=|\/)([0-9A-Za-z_-]{11})(?:[?&]|$)/)?.[1];
        if (videoId) {
            return {
                title: 'youtube_media',
                videoId: videoId,
                author: 'unknown',
                thumbnail: null
            };
        }
        throw error;
    }
}

async function downloadMedia(videoId, title, fmt) {
    const ext = fmt === 'mp3' ? 'mp3' : 'mp4';
    const filename = `${safeName(title)}.${ext}`;
    const outPath = path.join(DOWNLOAD_DIR, filename);
    const watchUrl = `https://www.youtube.com/watch?v=${videoId}`;

    const cmd = fmt === 'mp3'
        ? `yt-dlp -f bestaudio --extract-audio --audio-format mp3 --audio-quality 0 -o "${outPath}" "${watchUrl}"`
        : `yt-dlp -f "bestvideo[ext=mp4]+bestaudio[ext=m4a]/best[ext=mp4]/best" -o "${outPath}" "${watchUrl}"`;

    try {
        await execPromise(`${cmd} 2>/dev/null`);
        const stats = fs.statSync(outPath);
        return {
            success: true,
            filename,
            filepath: `download/${filename}`,
            size: stats.size
        };
    } catch (err) {
        // Fallback
        try {
            const fallbackCmd = fmt === 'mp3'
                ? `ffmpeg -i "$(yt-dlp -g -f bestaudio "${watchUrl}")" -c copy "${outPath}"`
                : `yt-dlp -f best -o "${outPath}" "${watchUrl}"`;

            await execPromise(`${fallbackCmd} 2>/dev/null`);
            const stats = fs.statSync(outPath);
            return {
                success: true,
                filename,
                filepath: `download/${filename}`,
                size: stats.size
            };
        } catch (fallbackError) {
            return { success: false, error: fallbackError.message };
        }
    }
}

async function main() {
    try {
        const info = await getVideoInfo(url);
        const result = await downloadMedia(info.videoId, info.title, format);

        if (!result.success) {
            console.log(JSON.stringify({
                success: false,
                platform: 'YouTube',
                error: result.error,
                creator: 'Exproject'
            }));
            process.exit(1);
        }

        console.log(JSON.stringify({
            success: true,
            platform: 'YouTube',
            id: info.videoId,
            title: info.title,
            author: info.author,
            type: format === 'mp3' ? 'audio' : 'video',
            thumbnail: info.thumbnail,
            url: url,
            filename: result.filename,
            filepath: result.filepath,
            size: result.size,
            download: result.filepath,
            creator: 'Exproject'
        }));

    } catch (error) {
        console.log(JSON.stringify({
            success: false,
            platform: 'YouTube',
            error: error.message,
            creator: 'Exproject'
        }));
        process.exit(1);
    }
}

main();