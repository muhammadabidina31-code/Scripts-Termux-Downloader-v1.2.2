const axios = require('axios');
const https = require('https');
const path = require('path');
const fs = require('fs');
const cheerio = require('cheerio');
const { exec } = require('child_process');
const util = require('util');
const execPromise = util.promisify(exec);
const args = process.argv.slice(2);
const url = args[0];
const format = (args[1] || 'mp4').toLowerCase();
const DOWNLOAD_DIR = path.join(__dirname, '..', 'download');
if (!fs.existsSync(DOWNLOAD_DIR)) fs.mkdirSync(DOWNLOAD_DIR, { recursive: true });

if (!url) {
    console.log(JSON.stringify({
        success: false,
        error: 'Usage: node TikTok.js <tiktok_url> [mp4|mp3]'
    }));
    process.exit(1);
}

if (!['mp3', 'mp4'].includes(format)) {
    console.log(JSON.stringify({
        success: false,
        error: `Unsupported format: ${format}. Use mp3 or mp4.`
    }));
    process.exit(1);
}

const agent = new https.Agent({ rejectUnauthorized: false, keepAlive: true });

const HEADERS = {
    'User-Agent': 'Mozilla/5.0 (Linux; Android 15; RMX3933 Build/AP3A.240905.015.A2) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.7871.46 Mobile Safari/537.36',
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8',
    'Accept-Language': 'id-ID,id;q=0.9,en-US;q=0.8',
    'Accept-Encoding': 'gzip, deflate, br',
    'sec-ch-ua': '"Not;A=Brand";v="8", "Chromium";v="150", "Android WebView";v="150"',
    'sec-ch-ua-mobile': '?1',
    'sec-ch-ua-platform': '"Android"',
    'Cache-Control': 'no-cache',
    'Pragma': 'no-cache',
    'Referer': 'https://musicaldown.net/',
    'Origin': 'https://musicaldown.net'
};

const client = axios.create({ httpsAgent: agent, headers: HEADERS, timeout: 30000 });

function clean(text) { return text?.replace(/\s+/g, ' ').trim() || undefined; }

function cleanNull(obj) {
    if (Array.isArray(obj)) {
        return obj.map(cleanNull).filter(v => v !== null && v !== undefined && !(Array.isArray(v) && v.length === 0));
    } else if (obj && typeof obj === 'object') {
        const cleaned = {};
        for (const [k, v] of Object.entries(obj)) {
            if (v !== null && v !== undefined && v !== '') {
                const cv = cleanNull(v);
                if (cv !== undefined &&
                    !(Array.isArray(cv) && cv.length === 0) &&
                    !(typeof cv === 'object' && Object.keys(cv).length === 0)) {
                    cleaned[k] = cv;
                }
            }
        }
        return Object.keys(cleaned).length > 0 ? cleaned : undefined;
    }
    return obj;
}

function safeBase(id, title) {
    const base = (title || `tiktok_${id || Date.now()}`)
        .substring(0, 40)
        .replace(/[^a-zA-Z0-9\s-]/g, '')
        .replace(/\s+/g, '_')
        .trim();
    return base || `tiktok_${id || Date.now()}`;
}

async function downloadVideo(directUrl, outPath) {
    try {
        await execPromise(`yt-dlp -o "${outPath}" "${directUrl}" 2>/dev/null`, { timeout: 180000 });
        if (fs.existsSync(outPath) && fs.statSync(outPath).size > 0) {
            return { success: true, method: 'yt-dlp' };
        }
    } catch (_) { /* fall through */ }

    try {
        await execPromise(
            `ffmpeg -y -loglevel error ` +
            `-user_agent "Mozilla/5.0 (Linux; Android 15)" ` +
            `-headers "Referer: https://musicaldown.net/\\r\\n" ` +
            `-i "${directUrl}" -c copy "${outPath}"`,
            { timeout: 180000 }
        );
        if (fs.existsSync(outPath) && fs.statSync(outPath).size > 0) {
            return { success: true, method: 'ffmpeg' };
        }
    } catch (err) {
        return { success: false, error: err.message };
    }

    return { success: false, error: 'Download produced no file' };
}

async function downloadAudio(directUrl, outPath) {
    try {
        await execPromise(
            `yt-dlp -x --audio-format mp3 --audio-quality 0 ` +
            `-o "${outPath}" "${directUrl}" 2>/dev/null`,
            { timeout: 180000 }
        );
        if (fs.existsSync(outPath) && fs.statSync(outPath).size > 0) {
            return { success: true, method: 'yt-dlp' };
        }
    } catch (_) { /* fall through */ }

    try {
        await execPromise(
            `ffmpeg -y -loglevel error ` +
            `-user_agent "Mozilla/5.0 (Linux; Android 15)" ` +
            `-headers "Referer: https://musicaldown.net/\\r\\n" ` +
            `-i "${directUrl}" -vn -acodec libmp3lame -q:a 0 "${outPath}"`,
            { timeout: 180000 }
        );
        if (fs.existsSync(outPath) && fs.statSync(outPath).size > 0) {
            return { success: true, method: 'ffmpeg' };
        }
    } catch (err) {
        return { success: false, error: err.message };
    }

    return { success: false, error: 'Download produced no file' };
}

async function getMusicaldownData(url) {
    try {
        const homeResponse = await client.get('https://musicaldown.net/id');
        const $ = cheerio.load(homeResponse.data);

        const csrfToken = $('meta[name="csrf-token"]').attr('content') ||
                          $('input[name="_token"]').val() ||
                          $('input[name="csrf-token"]').val();

        const formData = new URLSearchParams();
        formData.append('q', url);
        if (csrfToken) formData.append('_token', csrfToken);

        const postResponse = await client.post('https://musicaldown.net/api/ajaxSearch', formData, {
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
                'X-Requested-With': 'XMLHttpRequest',
                'Referer': 'https://musicaldown.net/id'
            }
        });

        const data = postResponse.data;
        const htmlContent = data.html || data.data || data;
        const $$ = cheerio.load(htmlContent);

        const title = clean($$('h3, .content h3, .caption').text()) ||
                      clean($$('meta[property="og:title"]').attr('content'));

        const thumbnail = $$('img[src*="tiktokcdn"]').attr('src') ||
                          $$('meta[property="og:image"]').attr('content');

        const tiktokId = $$('input#TikTokId').val();

        const video_sd = [];
        const video_hd = [];
        const audio = [];

        $$('a.tik-button-dl, a[download], a.btn-download').each((_, el) => {
            const href = $$(el).attr('href');
            const text = $$(el).text().toLowerCase();
            if (href && href.startsWith('http')) {
                if (text.includes('mp3') || href.includes('.mp3')) audio.push(href);
                else if (text.includes('hd') || text.includes('mp4 hd')) video_hd.push(href);
                else if (text.includes('mp4')) video_sd.push(href);
            }
        });

        const videoUrl = video_hd[0] || video_sd[0] || null;
        const audioUrl = audio[0] || null;

        return { title, thumbnail, tiktokId, videoUrl, audioUrl, video_sd, video_hd, audio };
    } catch (err) {
        return { error: err.message };
    }
}

async function main() {
    const data = await getMusicaldownData(url);

    if (data.error) {
        console.log(JSON.stringify({
            success: false, platform: 'TikTok', error: data.error, creator: 'Exproject'
        }));
        process.exit(1);
    }

    const sourceUrl = format === 'mp3'
        ? (data.audioUrl || data.videoUrl)   
        : (data.videoUrl || data.audioUrl);

    if (!sourceUrl) {
        console.log(JSON.stringify({
            success: false,
            platform: 'TikTok',
            url,
            title: data.title,
            error: 'No download URL found',
            creator: 'Exproject'
        }));
        process.exit(1);
    }

    const base = safeBase(data.tiktokId, data.title);
    const ext = format === 'mp3' ? 'mp3' : 'mp4';
    const filename = `${base}.${ext}`;
    const outPath = path.join(DOWNLOAD_DIR, filename);

    const dl = format === 'mp3'
        ? await downloadAudio(sourceUrl, outPath)
        : await downloadVideo(sourceUrl, outPath);

    if (!dl.success) {
        console.log(JSON.stringify({
            success: false,
            platform: 'TikTok',
            url,
            title: data.title,
            id: data.tiktokId,
            download: sourceUrl,
            error: `Download failed: ${dl.error}`,
            creator: 'Exproject'
        }));
        process.exit(1);
    }

    const stats = fs.statSync(outPath);

    console.log(JSON.stringify(cleanNull({
        success: true,
        platform: 'TikTok',
        id: data.tiktokId,
        title: data.title,
        author: 'unknown',
        type: format === 'mp3' ? 'audio' : 'video',
        thumbnail: data.thumbnail,
        url,
        filename,
        filepath: `download/${filename}`,
        size: stats.size,
        method: dl.method,
        download: `download/${filename}`,
        creator: 'Exproject'
    })));
}

main().catch(err => {
    console.log(JSON.stringify({
        success: false, platform: 'TikTok', error: err.message, creator: 'Exproject'
    }));
    process.exit(1);
});