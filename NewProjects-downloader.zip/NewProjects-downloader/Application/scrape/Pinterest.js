const axios = require('axios');
const https = require('https');
const cheerio = require('cheerio');
const args = process.argv.slice(2);
const url = args[0];
if (!url) {
    console.log(JSON.stringify({
        success: false,
        error: 'Usage: node Pinterest.js <pinterest_url>'
    }));
    process.exit(1);
}

const agent = new https.Agent({
    rejectUnauthorized: false,
    keepAlive: true
});

const MOBILE_HEADERS = {
    'User-Agent': 'Mozilla/5.0 (Linux; Android 15; RMX3933 Build/AP3A.240905.015.A2) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.7871.46 Mobile Safari/537.36',
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8',
    'Accept-Language': 'id-ID,id;q=0.9,en-US;q=0.8',
    'Accept-Encoding': 'gzip, deflate, br',
    'sec-ch-ua': '"Not;A=Brand";v="8", "Chromium";v="150", "Android WebView";v="150"',
    'sec-ch-ua-mobile': '?1',
    'sec-ch-ua-platform': '"Android"',
    'Origin': 'https://klickpin.com',
    'Referer': 'https://klickpin.com/id/',
    'Cache-Control': 'no-cache',
    'Pragma': 'no-cache'
};

function generateNonce() {
    const chars = 'abcdefghijklmnopqrstuvwxyz0123456789';
    let result = '';
    for (let i = 0; i < 24; i++) {
        result += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    return result;
}

function generateSignature() {
    const chars = 'abcdefghijklmnopqrstuvwxyz0123456789';
    let result = '';
    for (let i = 0; i < 64; i++) {
        result += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    return result;
}

function cleanNull(obj) {
    if (Array.isArray(obj)) {
        return obj.map(item => cleanNull(item))
                  .filter(item => item !== null && item !== undefined);
    } else if (obj && typeof obj === 'object') {
        const cleaned = {};
        for (const [key, value] of Object.entries(obj)) {
            if (value !== null && value !== undefined && value !== '') {
                cleaned[key] = cleanNull(value);
            }
        }
        return Object.keys(cleaned).length > 0 ? cleaned : undefined;
    }
    return obj;
}

async function getKlickpinData(pinUrl) {
    try {
        const response = await axios.get(
            `https://klickpin.com/id/download?url=${encodeURIComponent(pinUrl)}`,
            {
                httpsAgent: agent,
                headers: MOBILE_HEADERS,
                timeout: 30000,
                maxRedirects: 5
            }
        );

        const $ = cheerio.load(response.data);

        const result = {
            title: $('title').text().trim() || undefined,
            pin_id: undefined,
            image_url: undefined,
            image_url_hd: undefined,
            download_url: undefined,
            description: undefined,
            board: undefined,
            author: undefined,
            all_images: [],
            video_url: undefined,
            is_video: false
        };

        const titleMatch = result.title?.match(/pin-id-(\d+)/);
        if (titleMatch) result.pin_id = titleMatch[1];

        const imgElement = $('img[src*="pinimg.com"], img.download-image, img.pin-image, .pin-image img');
        if (imgElement.length) {
            const src = imgElement.first().attr('src') || imgElement.first().attr('data-src');
            if (src) {
                result.image_url = src;
                result.image_url_hd = src.replace('/564x/', '/originals/').replace('/236x/', '/originals/');
            }
        }

        const downloadBtn = $('a[download], a.btn-download, a[href*="download"], .download-btn, .btn-primary');
        if (downloadBtn.length) {
            const href = downloadBtn.first().attr('href');
            if (href && href !== '#' && href !== '/id/pinterest-image-downloader') {
                result.download_url = href.startsWith('http') ? href : `https://klickpin.com${href}`;
            }
        }

        const descElement = $('meta[property="og:description"], meta[name="description"], .pin-description, .description, .pin-desc');
        if (descElement.length) {
            const desc = descElement.first().attr('content') || descElement.first().text().trim();
            if (desc) result.description = desc;
        }

        const boardElement = $('.board-name, .board-title, a[href*="/board/"], .board-info');
        if (boardElement.length) {
            const board = boardElement.first().text().trim();
            if (board) result.board = board;
        }

        const authorElement = $('.author-name, .username, .creator-name, a[href*="/pin/"] .username');
        if (authorElement.length) {
            const author = authorElement.first().text().trim();
            if (author) result.author = author;
        }

        $('img').each((_, el) => {
            const src = $(el).attr('src') || $(el).attr('data-src');
            if (src && src.includes('pinimg.com')) {
                result.all_images.push(src);
            }
        });
        result.all_images = [...new Set(result.all_images)];

        const videoElement = $('video, source, .video-container, .pin-video');
        if (videoElement.length) {
            result.is_video = true;
            const videoSrc = videoElement.attr('src') || videoElement.find('source').attr('src');
            if (videoSrc) result.video_url = videoSrc;
        }

        if (result.all_images.length === 0) delete result.all_images;
        if (!result.is_video) delete result.is_video;
        if (!result.video_url) delete result.video_url;

        return cleanNull(result);

    } catch (error) {
        return null;
    }
}

async function resolveWithWorker(pinUrl) {
    try {
        const exp = Math.floor(Date.now() / 1000) + 7200;
        const nonce = generateNonce();
        const sig = generateSignature();

        const response = await axios.get(
            `https://resolve-94ebaa530357.vasinvictory3.workers.dev/?url=${encodeURIComponent(pinUrl)}&exp=${exp}&nonce=${nonce}&sig=${sig}`,
            {
                httpsAgent: agent,
                headers: {
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
                    'Accept': 'application/json, text/plain, */*',
                    'Accept-Language': 'id-ID,id;q=0.9,en-US;q=0.8',
                    'Origin': 'https://klickpin.com',
                    'Referer': 'https://klickpin.com/id/'
                },
                timeout: 10000
            }
        );
        return cleanNull(response.data);
    } catch (error) {
        return null;
    }
}

async function getPinItRedirect(pinId) {
    try {
        const response = await axios.get(
            `https://pin.it/${pinId}`,
            {
                httpsAgent: agent,
                headers: {
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
                    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8'
                },
                maxRedirects: 0,
                validateStatus: status => status === 302 || status === 301 || status === 200,
                timeout: 10000
            }
        );

        if (response.status === 302 || response.status === 301) {
            return response.headers.location;
        }

        const html = response.data;
        const match = html.match(/https:\/\/id\.pinterest\.com\/pin\/([a-zA-Z0-9]+)/);
        if (match) return match[0];

        return null;
    } catch (error) {
        if (error.response && (error.response.status === 302 || error.response.status === 301)) {
            return error.response.headers.location;
        }
        return null;
    }
}

async function processPin(inputUrl) {
    try {
        let pinId = inputUrl.match(/pin\.it\/([a-zA-Z0-9]+)/)?.[1]
                 || inputUrl.match(/pinterest\.[a-z.]+\/pin\/([a-zA-Z0-9]+)/)?.[1];

        if (!pinId) {
            return {
                success: false,
                platform: 'Pinterest',
                url: inputUrl,
                error: 'Invalid Pinterest URL'
            };
        }

        const result = {
            success: true,
            platform: 'Pinterest',
            url: inputUrl,
            pin_id: pinId
        };

        if (/pin\.it\//.test(inputUrl)) {
            const redirect = await getPinItRedirect(pinId);
            if (redirect) {
                result.redirect = redirect;
                const newPinId = redirect.match(/pin\/([a-zA-Z0-9]+)/)?.[1];
                if (newPinId) {
                    pinId = newPinId;
                    result.final_pin_id = pinId;
                }
            }
        }

        const klickpinData = await getKlickpinData(inputUrl);
        if (klickpinData) {
            result.klickpin = klickpinData;

            if (klickpinData.download_url === 'https://klickpin.com/id/pinterest-image-downloader') {
                delete result.klickpin.download_url;
                if (klickpinData.image_url_hd) {
                    result.klickpin.download_url = klickpinData.image_url_hd;
                } else if (klickpinData.image_url) {
                    result.klickpin.download_url = klickpinData.image_url;
                }
            }
        }

        const workerData = await resolveWithWorker(inputUrl);
        if (workerData) result.worker = workerData;

        const summary = {
            pin_id: pinId,
            title: klickpinData?.title,
            image: klickpinData?.image_url_hd || klickpinData?.image_url,
            download_url: klickpinData?.download_url || klickpinData?.image_url_hd || klickpinData?.image_url,
            description: klickpinData?.description,
            author: klickpinData?.author,
            board: klickpinData?.board,
            is_video: klickpinData?.is_video || false
        };

        if (summary.is_video === false) delete summary.is_video;
        result.summary = cleanNull(summary);
        result.id = summary.pin_id;
        result.title = summary.title || 'Pinterest Media';
        result.author = summary.author || 'unknown';
        result.type = klickpinData?.is_video ? 'video' : 'image';
        result.thumbnail = summary.image;
        result.download = summary.download_url;
        result.creator = 'Exproject';

        if (!result.klickpin && !result.worker) {
            result.success = false;
            result.error = 'Failed to get data from all sources';
        }

        return cleanNull(result) || result;

    } catch (error) {
        return {
            success: false,
            platform: 'Pinterest',
            url: inputUrl,
            error: error.message,
            creator: 'Exproject'
        };
    }
}

async function main() {
    try {
        const result = await processPin(url);
        console.log(JSON.stringify(result));
        if (!result.success) process.exit(1);
    } catch (error) {
        console.log(JSON.stringify({
            success: false,
            platform: 'Pinterest',
            error: error.message,
            creator: 'Exproject'
        }));
        process.exit(1);
    }
}

main();